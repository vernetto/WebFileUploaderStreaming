package net.codejava.upload;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

import net.lingala.zip4j.io.ZipOutputStream;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

public class CreateZipWithOutputStreams {
	
	public static void createZipWithOutputStreams(String inputFile, String password) throws Exception {
		System.out.println("inputFile=" + inputFile);
		
		// Input and OutputStreams are defined outside of the try/catch block
		// to use them in the finally block
		ZipOutputStream outputStream = null;
		InputStream inputStream = null;
		
		try {
			// Prepare the files to be added
			ArrayList<File> filesToAdd = new ArrayList<File>();
			filesToAdd.add(new File(inputFile));

			//Initiate output stream with the path/file of the zip file
			//Please note that ZipOutputStream will overwrite zip file if it already exists 
			outputStream = new ZipOutputStream(new FileOutputStream(new File(inputFile + ".zip")));
			
			// Initiate Zip Parameters which define various properties such
			// as compression method, etc. More parameters are explained in other
			// examples
			ZipParameters parameters = new ZipParameters();
			
			//Deflate compression or store(no compression) can be set below
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
			
			// Set the compression level. This value has to be in between 0 to 9
			// Several predefined compression levels are available
			// DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
			// DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
			// DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
			// DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
			// DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			
			//This flag defines if the files have to be encrypted.
			//If this flag is set to false, setEncryptionMethod, as described below,
			//will be ignored and the files won't be encrypted
			parameters.setEncryptFiles(true);
			
			//Zip4j supports AES or Standard Zip Encryption (also called ZipCrypto)
			//If you choose to use Standard Zip Encryption, please have a look at example
			//as some additional steps need to be done while using ZipOutputStreams with
			//Standard Zip Encryption
			parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
			
			//If AES encryption is used, this defines the key strength
			parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
			
			//self descriptive
			parameters.setPassword(password);
			
			//Now we loop through each file and read this file with an inputstream
			//and write it to the ZipOutputStream.
			for (int i = 0; i < filesToAdd.size(); i++) {
				File file = (File)filesToAdd.get(i);
				
				//This will initiate ZipOutputStream to include the file
				//with the input parameters
				outputStream.putNextEntry(file,parameters);
				
				//If this file is a directory, then no further processing is required
				//and we close the entry (Please note that we do not close the outputstream yet)
				if (file.isDirectory()) {
					outputStream.closeEntry();
					continue;
				}
				
				//Initialize inputstream
				inputStream = new FileInputStream(file);
				byte[] readBuff = new byte[4096];
				int readLen = -1;
				
				//Read the file content and write it to the OutputStream
				while ((readLen = inputStream.read(readBuff)) != -1) {
					outputStream.write(readBuff, 0, readLen);
				}
				
				//Once the content of the file is copied, this entry to the zip file
				//needs to be closed. ZipOutputStream updates necessary header information
				//for this file in this step
				outputStream.closeEntry();
				
				inputStream.close();
			}
			
			//ZipOutputStream now writes zip header information to the zip file
			outputStream.finish();
			
		} 
		finally {
			if (outputStream != null) {
					outputStream.close();
			}
			
			if (inputStream != null) {
					inputStream.close();
			}
		}
	}

}
